
<footer class="footer">
	<div class="d-sm-flex justify-content-center justify-content-sm-between">
		<span class="text-muted text-center text-sm-left d-block d-sm-inline-block">© 2021-22 clickdotpg..<a href="#" target="_blank"><?php  echo $_SESSION['companyname']; ?></a>. All rights reserved.</span>
        <span class="text-muted float-none float-sm-right d-block mt-1 mt-sm-0 text-center pr-3">Powered by: Shubhangi Hingu</span>
    </div>
</footer>