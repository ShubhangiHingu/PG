
<footer class="footer">
	<div class="d-sm-flex justify-content-center justify-content-sm-between">
		<span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2022 
            <!-- <a href="https://code4berry.com" target="_blank">code4berry.com</a>. -->Shubhangi Hingu
             All rights reserved.</span>
        <span class="text-muted float-none float-sm-right d-block mt-1 mt-sm-0 text-center pr-3">Powered by: Shubhangi Hingu</span>
    </div>
</footer>